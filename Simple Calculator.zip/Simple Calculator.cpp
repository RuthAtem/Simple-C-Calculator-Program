//Simple C++ calculator program
#include<iostream>
#include<math.h>
using namespace std;
int main(){
	double num1, num2 ;
	char op;
	while(1){
		cout<<"Enter the first number"<<endl;
		cin>>num1;
		cout<<"Enter the operation"<<endl;//operation can either be +,-,*,/,or s(square root)
		cin>>op;//Allows us enter the operator
		cout<<"Enter the second number"<<endl;
		cin>>num2;
		switch(op){
			case '+':
				cout<<"Sum is"<<num1+num2<<endl;//sums if the user enters +
				break;
			case '-':
				cout<<"Subtract is"<<num1-num2<<endl;//subtracts if the user enters -
				break;	
				case '*':
				cout<<"Multiple is"<<num1*num2<<endl;//Multiplies if the user enters *
				break;
				case '/':
				cout<<"Division is"<<num1/num2<<endl;//Divides if the user enters /
				break;
				case 's':
				cout<<"square root of"<<num1<<":"<<sqrt(num1)<<endl;/*finds the square root of num1 
				irrespective of num2 if user enters s*/
				break;
				default:
					cout<<"operator is illegal"<<endl;/*if the operator is other than the
					above this message is displayed*/ 
		}
	}
	return 0;
}
